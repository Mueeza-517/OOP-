using System;

namespace ATM;

public class Bank
{
  public int deposited_amount = 100000;
  public void Deposit()
  {
    Console.Write("Enter the amount to be deposited:");
    int deposit = int.Parse(Console.ReadLine());
    int Total_amount=deposited_amount+deposit;
    Console.Write("The amount you deposited is:" +Total_amount);
  }
    public void Withdraw()
  {
   
    Console.Write("Enter the amount you want to Withdraw:");
    int withdraw = int.Parse(Console.ReadLine());
    if(deposited_amount > withdraw)
    {
        int remaining_amount=deposited_amount-withdraw;
        Console.WriteLine("Remaining amount is " +remaining_amount);
        Console.Write("The amount you Withdraw is:" +withdraw);
    }
    else
    {
        Console.WriteLine("Sorry! you haven't enough amount in your Bank");
    }  
  }
   public void Check_Balance()
  {
    Console.WriteLine("If you want to check your current balance press any key");
    Console.ReadKey();
    Console.Write("your current balance is:" +deposited_amount);
  }

}
