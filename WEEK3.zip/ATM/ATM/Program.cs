﻿using System;
using System.Collections.Generic;

namespace ATM

{
    public class Program
    {
        static void Main(string[] args)
        {   
           
            Bank bank = new Bank();
            Console.WriteLine("Bank Management System");
            int option = Menu();
            while (option != 4)
            {
                switch (option)
                {
                    case 1:
                        
                        bank.Deposit();
                        break;
                    case 2:
                        
                        bank.Withdraw();
                        break;
                    case 3:
                    
                        bank.Check_Balance();
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        Console.WriteLine("Press any key.................");
                        break;
                }
                Console.ReadKey();
                option = Menu();
            }
        }
        

        public static int Menu()
        {

            Console.Clear();
            Console.WriteLine("-----BANK MENU-----");
            Console.WriteLine("1.Deposit the amount");
            Console.WriteLine("2.Withdraw the amount");
            Console.WriteLine("3.Check the balance ");
            Console.WriteLine("4.Exit");
        
            Console.WriteLine("Select the option(1--4)");
            int option = int.Parse(Console.ReadLine());
           
            return option;
        }
    }
}

