﻿using System;
using System.Collections.Generic;

namespace Calculator
{
    public class Program
    {
      static void Main(string[] args)
      {
        float number1,number2;
         Calculate calculate = new Calculate(); //agr hmm constructor  my arguments pass nhi karein gy to yahan bhi nhi karein gy

         Console.WriteLine("Enter first number");
          calculate.number1 = float.Parse(Console.ReadLine());
         Console.WriteLine("Enter second number");
          calculate.number2 = float.Parse(Console.ReadLine());
         float add = calculate.Add();
         Console.WriteLine("Sum is:" +add);
         float subtract = calculate.Subtract();
         Console.WriteLine("Subtraction is:" +subtract);
         float multiply = calculate.Multiply();
         Console.WriteLine("Multiplication is:" +multiply);
         float divide = calculate.Divide();
         Console.WriteLine("Division is:" +divide);
      }
    }
}
