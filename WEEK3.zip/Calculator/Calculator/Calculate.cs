using System;

namespace Calculator
{
   
    public class Calculate
    {
        public Calculate()//default constructor
        {

        }
         public Calculate(float num1 , float num2 ) //parameterized constructor
    {
          number1 = num1 ;
          number2 = num2 ;
    }
        public float number1;

        public float number2;

        public float Add()
        {
            return number1+number2;
        }

        public float Subtract()
        {
            return number1-number2;
        }

        public float Multiply()
        {
            return number1*number2;
        }

        public float Divide()
        {
            return number1/number2;
        }
    }
}
