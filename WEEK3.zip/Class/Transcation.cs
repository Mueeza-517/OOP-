using System;

namespace Class;

public class Transcation
{
  public string transcation_id;
  public string product_name;
  public string amount;
  public string date;
  public string time;

  public Transcation()
  {
    date = "null";
    transcation_id = "null";
    product_name = "null";
    amount = "null";
    time = "null";
  }
}
