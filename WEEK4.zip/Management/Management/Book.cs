using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Management
{
   internal class Book
    {
        public string title;
        public string[] author=new string[4];
        public string publisher;
        public string ISBN;
        public float price;
        public int stock;
        public int year;
        public  string tax;
        public Book(string title, string[] author, string publisher,  string iSBN,  float price, int stock, int year)
        {
            this.title = title;
            this.author = author;
            this.publisher = publisher;
            ISBN = iSBN;
            this.price = price;
            this.stock = stock;
            this.year = year;
            this.tax = "5%";
        }
        public Book(Book book)
        {
            this.title = book.title;
            this.author = book.author;
            this.publisher = book.publisher;
            this.stock = book.stock;
            this.year = book.year;
            this.ISBN = book.ISBN;
        }
        public void salebook(int x, int y)
        {
            gotoxy(x, y);
            Console.Write(title.PadRight(15));
            Console.Write(price.ToString().PadRight(15));
            Console.Write("0%".ToString().PadRight(15));
            Console.Write("5%".ToString().PadRight(15));
            price = ((price) * 1.05F);
            Console.Write(price.ToString().PadRight(15));
        }
        public void salebook1(int x, int y)
        {
            gotoxy(x, y);
            Console.Write(title.PadRight(15));
            Console.Write(price.ToString().PadRight(15));
            Console.Write("10%".PadRight(15));
            Console.Write("5%".ToString().PadRight(15));
            price = ((price) * 9.5F);
            Console.Write((price).ToString().PadRight(15));
        }

        public void display(int x, int y)
        {
            gotoxy(x, y);
            Console.Write( title.PadRight(15));
            Console.Write((author[0].PadRight(15)));
            Console.Write((author[1].PadRight(15)));
            Console.Write((author[2].PadRight(15)));
            Console.Write((author[3].PadRight(15)));
            Console.Write( price.ToString().PadRight(15));
            Console.Write( stock.ToString().PadRight(15));
            Console.Write( year.ToString().PadRight(15));
            Console.Write( ISBN.PadRight(15));
            Console.Write( publisher.PadRight(15));
            
        }
        public void  output(int x , int y)
        {
            gotoxy(x, y);
            Thread.Sleep(50);
            Console.WriteLine("Title".PadRight(15) + title.PadRight(15));
            gotoxy(x, y + 1);
            Thread.Sleep(50);
            Console.WriteLine(("Author1".PadRight(15) + author[0].PadRight(15)));
            gotoxy(x, y + 2);
            Thread.Sleep(50);
            Console.WriteLine(("Author2".PadRight(15) + author[1].PadRight(15)));
            gotoxy(x, y + 3);
            Thread.Sleep(50);
            Console.WriteLine("Author3".PadRight(15) + (author[2].PadRight(15)));
            gotoxy(x, y + 4);
            Thread.Sleep(50);
            Console.WriteLine(("Author4".PadRight(15) + author[3].PadRight(15)));
            gotoxy(x, y + 5);
            Thread.Sleep(50);
            Console.WriteLine("Price ".PadRight(15) + price.ToString().PadRight(15));
            gotoxy(x, y + 6);
            Thread.Sleep(50);
            Console.WriteLine("Stock ".PadRight(15) + stock.ToString().PadRight(15));
            gotoxy(x, y + 7);
            Console.WriteLine("Year".PadRight(15) + year.ToString().PadRight(15));
            gotoxy(x, y + 8);
            Console.WriteLine("ISBN".PadRight(15) + ISBN.PadRight(15));
            gotoxy(x, y + 9);
            Thread.Sleep(50);
            Console.WriteLine("Publisher".PadRight(15) + publisher.PadRight(15));
            gotoxy(x, y + 10);
            Thread.Sleep(50);
            Console.WriteLine("Press any Key for Going back");
            Console.ReadKey();
        }
        static void gotoxy(int x, int y)
        {
            Console.SetCursorPosition(x, y);
        }
    }
}



