using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Management
{
    internal class Member
    {
        public string name;
        public string memberID;
        public int Listofbooksbought;
        public int numberofbooksbought;
        public float moneyInBank;
        public int amountspent;
        public float buyBookMiney;
        public float benifit;
        public List<Book> BOOKS = new List<Book>();
        public Member(string name, string memberID, float moneyInBank, int amountspent)
        {
            this.name = name;
            this.memberID = memberID;
            this.numberofbooksbought = 0;
            this.moneyInBank = moneyInBank;
            this.amountspent = amountspent;
            this.benifit = 0;
            this.buyBookMiney = 0;
        }
        public void processCompleted(string[] title, string amount, List<Book> books)
        {
            moneyInBank -= float.Parse(amount);
            buyBookMiney += float.Parse(amount);
            List<int> num = new List<int>();
            for (int i = 0; i < title.Length; i++)
            {
                for (int j = 0; j < books.Count; j++)
                {
                    if (title[i] == books[j].title)
                    {
                        num.Add(j);
                    }
                }
            }
            foreach (int i in num)
            {
                BOOKS.Add(books[i]);
            }
            numberofbooksbought += num.Count;

        }
        public void BuyBOOKS(List<Book> books)
        {
            int lX = 30, lY = 13;
            gotoxy(lX - 25, lY + 4);
            Console.WriteLine("Sr No".PadRight(8) + "title".PadRight(15) + "author1".PadRight(15) + "author2".PadRight(15) + "author3".PadRight(15) + "author4".PadRight(15) + "Price".PadRight(15) + "Stock".PadRight(15) + "Year".PadRight(15) + "ISBN".PadRight(15) + "Publisher".PadRight(15));
            for (int i = 0; i < books.Count; i++)
            {
                Thread.Sleep(80);
                gotoxy(lX - 25, lY + 5 + i);
                Console.Write(i.ToString().PadRight(8));
                books[i].display(lX - 17, lY + 5 + i);
            }
        }
        public Member(string name, string memberID, int moneyInBank)
        {
            this.name = name;
            this.memberID = memberID;
            this.numberofbooksbought = 0;
            this.moneyInBank = moneyInBank;
            this.amountspent = 0;
            this.benifit = 0;
            this.buyBookMiney = 0;
        }
        public float cart(string[] title, List<Book> books)
        {
            float price = 0;
            int lX = 30, lY = 13;
            List<int> num = new List<int>();
            for (int i = 0; i < title.Length; i++)
            {
                for (int j = 0; j < books.Count; j++)
                {
                    if (title[i] == books[j].title)
                    {
                        num.Add(j);
                    }
                }
            }
            gotoxy(lX, lY);
            Console.WriteLine("Title".PadRight(15) + "Price".PadRight(15) + "Discound".PadRight(15) + " Tax".PadRight(15)+ "Price After Discound".PadRight(25));
            for (int x = 0; x < num.Count; x++)
            {
                price += books[x].price;
                Thread.Sleep(80);
                books[x].salebook(lX, lY + x + 2);
            }
            Console.WriteLine();
            return price;
        }
        public float cart1(string[] title, List<Book> books)
        {
            float price = 0;
            int lX = 30, lY = 13;
            List<int> num = new List<int>();
            for (int i = 0; i < title.Length; i++)
            {
                for (int j = 0; j < books.Count; j++)
                {
                    if (title[i] == books[j].title)
                    {
                        num.Add(j);
                    }
                }
            }
            gotoxy(lX, lY);
            Console.WriteLine("Title".PadRight(15) + "Price".PadRight(15) + "Discound".PadRight(15) + "Tax".PadRight(15) + "Price After Discound".PadRight(25));
            for (int x = 0; x < num.Count; x++)
            {
                benifit += ((books[x].price) * 0.1F);
                price += ((books[x].price) * 0.9F);
                Thread.Sleep(80);
                books[x].salebook(lX, lY + x + 2);
            }
            Console.WriteLine();
            return price;
        }
        public void output(int x, int y)
        {
            int i = 0;
            gotoxy(x, y);
            Thread.Sleep(50);
            Console.WriteLine("name".PadRight(50) + name.PadRight(15));
            gotoxy(x, y + 1);
            Thread.Sleep(50);
            Console.WriteLine(("Member ID".PadRight(50) + memberID.PadRight(15)));
            gotoxy(x, y + 2);
            Thread.Sleep(50);
            Console.WriteLine("Money in Bank ".PadRight(50) + moneyInBank.ToString().PadRight(15));
            gotoxy(x, y + 3);
            Thread.Sleep(50);
            Console.WriteLine("Amount Spent".PadRight(50) + amountspent.ToString().PadRight(15));
            gotoxy(x, y + 4);
            Thread.Sleep(50);
            Console.WriteLine(("Number of Books Bought".PadRight(50) + numberofbooksbought.ToString().PadRight(15)));
            gotoxy(x, y + 5);
            Thread.Sleep(50);
            Console.WriteLine(("Amount spent for buy book".PadRight(50) + buyBookMiney.ToString().PadRight(15))); gotoxy(x, y + 4);
            Thread.Sleep(50);
            gotoxy(x, y + 6);
            Console.WriteLine(("Benefit Against Membership fee".PadRight(50) + benifit.ToString().PadRight(15)));
            if (numberofbooksbought > 0)
            {
                gotoxy(x, y + 7);
                Thread.Sleep(50);
                Console.WriteLine("Press 1 for seeing book list or");
                gotoxy(x, y + 8);
                Thread.Sleep(50);
                Console.Write("Press any Key for Going back    ");
                string list = Console.ReadLine();
                if (list == "1")
                {
                    gotoxy(x, y + 9 + i);
                    Console.WriteLine("Title".PadRight(15) + "Price".PadRight(15));
                    for (i = 0; i < numberofbooksbought; i++)
                    {
                        gotoxy(x, y + 10 + i);
                        Thread.Sleep(50);
                        Console.WriteLine(BOOKS[i].title.PadRight(15) + BOOKS[i].price.ToString().PadRight(30));
                    }
                }
            }
            gotoxy(x, y + 12 + i);
            Thread.Sleep(50);
            Console.WriteLine("Press any Key for Going back");
            Console.ReadKey();
        }
        public void diaplay(int x, int y, string discound)
        {
            gotoxy(x, y);
            Console.Write(name.PadRight(15));
            Console.Write((memberID.PadRight(15)));
            Console.Write((moneyInBank.ToString().PadRight(20)));
            Console.Write((amountspent.ToString().PadRight(20)));
            Console.Write((numberofbooksbought.ToString().PadRight(20)));
            Console.Write(discound.ToString().PadRight(15));
            Console.Write(benifit.ToString().PadRight(15));
            Console.Write(buyBookMiney.ToString().PadRight(20));
        }
        static void gotoxy(int x, int y)
        {
            Console.SetCursorPosition(x, y);
        }
    }
}



