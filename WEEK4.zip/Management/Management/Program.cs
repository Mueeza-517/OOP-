﻿using System;
using System.Collections;

namespace Management
{
    class Program
    {
        static int lX = 30, lY = 13;
        static int TotalAmount = 0;

        static void Main(string[] args)
        {
            string[] author = new string[4] { "ww", "ss", "ss", "ww " };
            List<Member> nonmember = new List<Member>();
            List<Member> members = new List<Member>();
            List<Book> Books = new List<Book>();
            Member m = new Member("mueeza", "0", 300000);
            Member m1 = new Member("mueeza", "1", 30000, 1395);
            members.Add(m1);
            nonmember.Add(m);
            Book b1 = new Book("ss", author, "22222222222", "22", 2222, 222, 3333333);
            Book b2 = new Book("s", author, "22222222222", "22", 2222, 222, 3333333);
            Book b3 = new Book("sws", author, "22222222222", "22", 22222, 222, 3333333);
            Book b4 = new Book("sse", author, "22222222222", "22", 2222, 222, 3333333);
            Books.Add(b1);
            Books.Add(b2);
            Books.Add(b3);
            Books.Add(b4);
            string LogIn = "";
            while (LogIn != "3")
            {
                LogIn = MainMenu();
                if (LogIn == "1")
                {
                    while (LogIn != "10")
                    {
                        LogIn = Menu();
                        if (LogIn == "1")
                        {
                            Books.Add(BookAdd());
                        }
                        else if (LogIn == "2")
                        {
                            BookSearchbyName(Books);
                        }
                        else if (LogIn == "3")
                        {
                            BookSearchbyISBN(Books);
                        }
                        else if (LogIn == "4")
                        {
                            Update(Books);
                        }
                        else if (LogIn == "5")
                        {

                        }
                        else if (LogIn == "6")
                        {
                            MemberSearchbyName(nonmember);
                        }
                        else if (LogIn == "7")
                        {
                            MemberSearchbyID(members);
                        }
                        else if (LogIn == "8")
                        {
                            DisplayMembers( members , nonmember);
                        }
                        else if (LogIn == "9")
                        {
                            DisplayBook(Books);
                        }

                    }

                }
                else if (LogIn == "2")
                {
                    while (LogIn != "4")
                    {
                        LogIn = CustomerMenu();
                        if (LogIn == "1")
                        {
                            int number = -1;
                            LogIn = login(nonmember, members, ref number);
                            if (LogIn == "0")
                            {
                                NonMemberBuy(Books, nonmember, number);
                            }
                            if (LogIn == "1")
                            {
                                NonMemberBuy(Books, members , number);
                            }
                        }
                        else if (LogIn == "2")
                        {
                            AddMember(members);
                        }
                        else if (LogIn == "3")
                        {
                            ADDnonMemberCustomer(nonmember);
                        }

                    }

                }

            }
        }

        static string MainMenu()
        {
            int lX = 30, lY = 13;
            animation();
            string option;
            gotoxy(lX, lY);
            Thread.Sleep(50);
            Console.WriteLine("\t\t Press ");
            gotoxy(lX, lY + 1);
            Thread.Sleep(50);
            Console.WriteLine("\t\t 1) IF you are admin");
            gotoxy(lX, lY + 3);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 2) IF you are Customer");
            gotoxy(lX, lY + 5);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 3) Exit");
            gotoxy(lX + 19, lY + 6);
            Thread.Sleep(100);
            option = Console.ReadLine();
            return option;
        }
        static string Menu()
        {
            int lX = 30, lY = 13;
            string option;
            animation();
            gotoxy(lX, lY);
            Thread.Sleep(50);
            Console.WriteLine("\t Choose you want to do.... ");
            gotoxy(lX, lY + 1);
            Thread.Sleep(50);
            Console.WriteLine("\t\t 1) Add  Book");
            gotoxy(lX, lY + 2);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 2) Search By Name");
            gotoxy(lX, lY + 3);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 3) Search By ISBN");
            gotoxy(lX, lY + 4);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 4) Update Copies of Books ");
            gotoxy(lX, lY + 5);
            Thread.Sleep(50);
            Console.WriteLine("\t\t 5) Show All Cash Details");
            gotoxy(lX, lY + 6);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 6) Search Member by Name");
            gotoxy(lX, lY + 7);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 7) Search Member by MAmberID");
            gotoxy(lX, lY + 8);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 8) Show all Members");
            gotoxy(lX, lY + 9);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 9) Show all Books");
            gotoxy(lX, lY + 10);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 10) Exit");
            gotoxy(lX, lY + 11);
            Thread.Sleep(100);
            Console.Write("\t Enter Your Option (1-5): ");
            option = Console.ReadLine();
            return option;
        }
        static string CustomerMenu()
        {
            int lX = 30, lY = 13;
            animation();
            string option = "";
            gotoxy(lX, lY);
            Thread.Sleep(50);
            Console.WriteLine("\t\t Press ");
            gotoxy(lX, lY + 1);
            Thread.Sleep(50);
            Console.WriteLine("\t\t 1) IF you are registered as member or Non Member Customer");
            gotoxy(lX, lY + 2);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 2) Sign Up for Membership");
            gotoxy(lX, lY + 3);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 3) IF you are Occasionally Customer");
            gotoxy(lX, lY + 4);
            Thread.Sleep(100);
            Console.WriteLine("\t\t 4) Exit");
            gotoxy(lX + 19, lY + 5);
            Thread.Sleep(100);
            option = Console.ReadLine();
            while (option != "1" && option != "2" && option != "3" && option != "4")
            {
                Thread.Sleep(50);
                gotoxy(lX + 25, lY + 6);
                Console.WriteLine("Wrong Option ");
                Thread.Sleep(50);
                gotoxy(lX + 25, lY + 7);
                Console.WriteLine("Press any Key for enter option again");
                Console.ReadKey();
                gotoo11(lX + 19, lY + 5);
                option = Console.ReadLine();
            }
            return option;
        }

        static void ADDnonMemberCustomer(List<Member> members)
        {
            animation();
            string name = "", ID = "";
            int price;
            string[] author = new string[4];
            gotoxy(lX + 4, lY + 2);
            Thread.Sleep(100);
            Console.WriteLine("Member Detailes :");
            gotoxy(lX + 4, lY + 4);
            Thread.Sleep(100);
            Console.Write("Enter Name  :");
            Thread.Sleep(100);
            gotoxy(lX + 4, lY + 5);
            Console.Write("Enter Money in Bank :");
            Thread.Sleep(100);
            name = nameCheck1(lX + 25, lY + 4);
            price = numericChec(lX + 25, lY + 5);
            int count = 0;
            ID = count.ToString();
            Member member = new Member(name, ID, price);
            members.Add(member);
            Thread.Sleep(100);
            gotoxy(lX + 25, lY + 6);
            Console.WriteLine("Data ADded Sucessfully ");
            Thread.Sleep(50);
            gotoxy(lX + 25, lY + 7);
            Console.WriteLine("Press any Key for Further Proccessing");
            Console.ReadKey();
        }
        static string login(List<Member> members, List<Member> memb, ref int X)
        {
            bool result = false;
            int C = 0;
            animation();
            string name = "", ID = "";
            string[] author = new string[4];
            gotoxy(lX + 4, lY + 2);
            Thread.Sleep(100);
            Console.WriteLine("Member Detailes :");
            gotoxy(lX + 4, lY + 4);
            Thread.Sleep(100);
            Console.Write("Enter Name  :");
            Thread.Sleep(100);
            gotoxy(lX + 4, lY + 5);
            Console.Write("Enter Member ID :");
            Thread.Sleep(100);
            name = nameCheck1(lX + 25, lY + 4);
            ID = ageChec1(lX + 25, lY + 5);
            if (ID == "0")
            {
                foreach (Member member in members)
                {
                    if (member.name == name && member.memberID == ID)
                    {
                        X = C;
                    }
                    C++;
                }
            }
            else
            {
                foreach (Member member in memb)
                {
                    if (member.name == name && member.memberID == ID)
                    {
                        X = C;
                    }
                    C++;
                }
            }
            if (X == -1)
            {
                Thread.Sleep(100);
                gotoxy(lX + 4, lY + 6);
                Console.WriteLine("Your Data  not Found");
                Thread.Sleep(100);
                gotoxy(lX + 4, lY + 7);
                Console.WriteLine("Press any key for going back");
                Console.ReadLine();
            }
            return ID;

        }
        static void gotoxy(int x, int y)
        {
            Console.SetCursorPosition(x, y);
        }
        static void animation()
        {
            int x1 = 4, y1 = 13;
            for(int x=0; x<20; x++)
            {
                gotoxy(x1, y1 + x);
                Console.WriteLine("                                                                                                       ");
                Thread.Sleep(150);
            }          
        }
        static void animation2(int x, int y)
        {
            for (int i = 0; i < 15; i++)
            {
                gotoxy(x, y + i);
                Console.WriteLine("                                                                                                                                                                                                             ");
                Thread.Sleep(150);
            }
        }
        static void animation1()
        {
            int x1 = 16, y1 = 12;
            for(int x=0; x< 20; x++)
            {
                gotoxy(x1, y1 + x);
                Console.WriteLine("                                                                                                                                                                                                             ");
                Thread.Sleep(150);
            }                                      
        }
        static void NonMemberBuy(List<Book> books, List<Member> Member, int number)
        {
            int count, x=0 , coun=0;
            animation();
            string[] title = new string[1000];
            Member[number].BuyBOOKS(books);
            string option = "";
            while (option == "")
            {
                Console.Write("\t\t\tHow many books you want to buy ");
                count = int.Parse(Console.ReadLine());
                for ( x = coun; x < (count+coun); x++)
                {
                    Console.Write("\t\t\tEnter title of book" + (x + 1));
                    title[x] = Console.ReadLine();
                }
                coun = count;
                Console.WriteLine("\t\t\tpress");
                Console.WriteLine("\t\t\t 1 to see cart ");
                Console.Write("\t\t\t 2 to enter more books ");
                count = int.Parse(Console.ReadLine());
                float amount = 0;
                if (count == 1)
                {
                    animation1();
                    if(Member[number].memberID == "0")
                    { 
                    amount = Member[number].cart(title, books);
                    }
                    else if (Member[number].memberID != "0")
                    {
                        amount = Member[number].cart1(title, books);
                    }
                        Console.WriteLine();
                    Console.WriteLine("\t\t\t\ttotal price   :" + amount);
                    Console.WriteLine("\t\t\t\tPress  any key for payment");
                    Console.ReadKey();
                    if (amount < Member[number].moneyInBank)
                    {
                        Member[number].processCompleted(title, amount.ToString(), books);
                        Console.WriteLine("\t\t\t\tcongratulations you buy the book");
                        Console.Write("\t\t\t\tPress G key for going back");
                        option = Console.ReadLine();
                    }
                    else
                    {
                        Console.Write("\t\t\tPress G key for going back");
                        option = Console.ReadLine();
                    }
                }
                else if (count == 2)
                {
                    animation2(lX - 22 , lY + 5 + books.Count);
                    gotoxy(lX - 25, lY + 5 + books.Count);
                 }
            }
        }
        static Book BookAdd()
        {
            animation();
            string title = "", ISBN = "", publisher = "";
            int stock, year;
            int productprize = 0;
            string[] author = new string[4];
            gotoxy(lX + 4, lY + 2);
            Thread.Sleep(100);
            Console.WriteLine("Book Detailes :");
            gotoxy(lX + 4, lY + 4);
            Thread.Sleep(100);
            Console.Write("Enter Title  :");
            gotoxy(lX + 4, lY + 5);
            Thread.Sleep(100);
            Console.Write("Enter Authors name :");
            for (int i = 0; i < 4; i++)
            {
                Thread.Sleep(100);
                gotoxy(lX + 4, lY + 6 + i);
                Console.Write("author" + (i + 1));
            }
            Thread.Sleep(100);
            gotoxy(lX + 4, lY + 10);
            Console.Write("Enter Prize :");
            Thread.Sleep(100);
            gotoxy(lX + 4, lY + 11);
            Console.Write("Enter Stock :");
            Thread.Sleep(100);
            gotoxy(lX + 4, lY + 12);
            Console.Write("Enter ISBN Code :");
            Thread.Sleep(100);
            gotoxy(lX + 4, lY + 13);
            Console.Write("Enter Year :");
            Thread.Sleep(100);
            gotoxy(lX + 4, lY + 14);
            Console.Write("Enter Publisher :");
            Thread.Sleep(100);
            title = nameCheck1(lX + 25, lY + 4);
            gotoxy(lX + 19, lY + 5);
            for (int i = 0; i < 4; i++)
            {
                author[i] = nameCheck1(lX + 25, lY + 6 + i);
            }
            productprize = numericChec(lX + 25, lY + 10);
            stock = numericChec(lX + 25, lY + 11);
            ISBN = numberChec1(lX + 25, lY + 12);
            year = numericChec(lX + 25, lY + 13);
            publisher = nameCheck1(lX + 25, lY + 14);
            Book books = new Book(title, author, publisher, ISBN, productprize, stock, year);
            return books;

        }
        static void BookSearchbyName(List<Book> books)
        {
            string name;
            animation();
            int X = -1;
            gotoxy(lX + 4, lY + 2);
            Console.Write("Write the  title of Book   :");
            name = Console.ReadLine();
            foreach (Book book in books)
            {
                if (name == book.title)
                {
                    book.output(lX + 4, lY + 4);
                }
                else
                {
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 3);
                    Console.WriteLine("This Book is not Availible ");
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 4);
                    Console.WriteLine("Press any Key for Going back");
                    Console.ReadKey();
                }
            }
        }
        static void DisplayBook(List<Book> books)
        {
            int i = 0;
            animation();
            gotoxy(lX + 4, lY + 4);
            Console.Write("title".PadRight(15) + "author1".PadRight(15) + "author2".PadRight(15) + "author3".PadRight(15) + "author4".PadRight(15) + "Price".PadRight(15) + "Stock".PadRight(15) + "Year".PadRight(15) + "ISBN".PadRight(15) + "Publisher".PadRight(15));
            foreach (Book book in books)
            {
                Thread.Sleep(80);
                book.display(lX + 4, lY + 5 + i);
                i++;
            }
            Thread.Sleep(50);
            gotoxy(lX + 25, lY + 6 + books.Count);
            Console.WriteLine("Press any Key for Going back");
            Console.ReadKey();
            animation1();


        }
        static void DisplayMembers(List <Member> members , List<Member> nonmember)
        {
            int i = 0;
            animation();
            gotoxy(lX - 15, lY + 4);
            Console.Write("name".PadRight(15) + "Member ID".PadRight(15) + "Money in Bank".PadRight(20) + "Membership fee".PadRight(20) + "no of buy Books".PadRight(20) + "Discound".PadRight(15) + "Benifit".PadRight(15) + "Total amount for books".PadRight(20));
            foreach(Member member in members)
            { 
            Thread.Sleep(80);
                member.diaplay(lX -  15, lY + 5 + i, "10%");
                i++;
            }
            foreach (Member member in nonmember)
            {
                Thread.Sleep(80);
                member.diaplay(lX - 15, lY + 5 + i, "0%");
                i++;
            }
            Thread.Sleep(50);
            gotoxy(lX + 25, lY + 6 +  members.Count + nonmember.Count);
            Console.WriteLine("Press any Key for Going back");
            Console.ReadKey();
            animation1();

        }
        static void MemberSearchbyName(List<Member> members)
        {
            string name;
            animation();
            int X = -1;
            gotoxy(lX + 4, lY + 2);
            Console.Write("Write the   name of Member   :");
            name = Console.ReadLine();
            foreach (Member Members in members)
            {
                if (name == Members.name)
                {
                    Members.output(lX + 4, lY + 4);
                }
                else
                {
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 3);
                    Console.WriteLine("This  name is not  found ");
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 4);
                    Console.WriteLine("Press any Key for Going back");
                    Console.ReadKey();
                }
            }
        }
        static void MemberSearchbyID(List<Member> members)
        {
            string name;
            animation();
            int X = -1;
            gotoxy(lX + 4, lY + 2);
            Console.Write("Write the   ID of Member   :");
            name = Console.ReadLine();
            foreach (Member Members in members)
            {
                if (name == Members.memberID)
                {
                    Members.output(lX + 4, lY + 4);
                }
                else
                {
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 3);
                    Console.WriteLine("This  name is not  found ");
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 4);
                    Console.WriteLine("Press any Key for Going back");
                    Console.ReadKey();
                }
            }
        }
        static void Update(List<Book> books)
        {
            string name;
            animation();
            int X = -1;
            gotoxy(lX + 4, lY + 2);
            Console.Write("Write the  title of Book   :");
            name = Console.ReadLine();
            foreach (Book book in books)
            {
                if (name == book.title)
                {
                    Console.WriteLine("Enter updated STock of book");
                    book.stock = int.Parse(Console.ReadLine());
                }
                else
                {
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 3);
                    Console.WriteLine("This Book is not Availible ");
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 4);
                    Console.WriteLine("Press any Key for Going back");
                    Console.ReadKey();
                }
            }
        }
        static void BookSearchbyISBN(List<Book> books)
        {
            string name;
            int X = -1;
            animation();
            gotoxy(lX + 4, lY + 2);
            Console.Write("Write the   ISBN of Book   :");
            name = Console.ReadLine();
            foreach (Book book in books)
            {
                if (name == book.ISBN)
                {
                    book.output(lX + 4, lY + 4);
                }
                else
                {
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 3);
                    Console.WriteLine("This Book is not Availible ");
                    Thread.Sleep(50);
                    gotoxy(lX + 25, lY + 4);
                    Console.WriteLine("Press any Key for Going back");
                    Console.ReadKey();
                }
            }
        }
        static void AddMember(List<Member> memb)
        {
            animation();
            Thread.Sleep(100);
            gotoxy(lX + 25, lY + 4);
            Console.WriteLine("You should Pay RS {0} yearly as membership fee ", 279 * 5);
            Thread.Sleep(50);
            gotoxy(lX + 25, lY + 5);
            Console.WriteLine("Press any Key for Further Proccessing");
            Console.ReadKey();
            animation();
            string name = "", ID = "";
            int price;
            string[] author = new string[4];
            gotoxy(lX + 4, lY + 2);
            Thread.Sleep(100);
            Console.WriteLine("Member Detailes :");
            gotoxy(lX + 4, lY + 4);
            Thread.Sleep(100);
            Console.Write("Enter Name  :");
            Thread.Sleep(100);
            gotoxy(lX + 4, lY + 5);
            Console.Write("Enter Money in Bank :");
            Thread.Sleep(100);
            name = nameCheck1(lX + 25, lY + 4);
            price = numericChec(lX + 25, lY + 5);
            int count = memb.Count + 1;
            ID = count.ToString();
            if (price > 279 * 10)
            {
                price -= 279 * 3;
                Member members = new Member(name, ID, price, 279 * 5);
                memb.Add(members);
                TotalAmount += 279 * 3;
                Thread.Sleep(100);
                gotoxy(lX + 25, lY + 6);
                Console.WriteLine("Rs 1395 deducted from your account");
                Thread.Sleep(100);
                gotoxy(lX + 25, lY + 7);
                Console.WriteLine("Account Created Sucessfully ");
                Thread.Sleep(100);
                gotoxy(lX + 25, lY + 8);
                Console.WriteLine("Your Member ID is  " + ID);
                Thread.Sleep(50);
                gotoxy(lX + 25, lY + 9);
                Console.WriteLine("Press any Key for Further Proccessing");
                Console.ReadKey();

            }
            else
            {
                Thread.Sleep(100);
                gotoxy(lX + 25, lY + 6);
                Console.WriteLine("Account not created as balance is less than  {0}", 5 * 279);
                Thread.Sleep(50);
                gotoxy(lX + 25, lY + 7);
                Console.WriteLine("Press any Key for Further Proccessing");
                Console.ReadKey();

            }
        }
        static string nameCheck1(int x, int y)
        {
            string name;
            gotoxy(x, y);
            name = Console.ReadLine();
            while (isDomicileCheck2(name))
            {
                gotoxy(x, y + 1);
                Console.WriteLine("WRONG DATA PLEASE ENTER CORRECT NAME  ");
                gotoxy(x, y + 2);
                Console.WriteLine("Press any key for going back  ");
                Console.ReadKey();
                gotoo11(x, y);
                name = Console.ReadLine();
            }
            return name;
        }
        
        static string ageChec1(int x, int y)
        {
            string age;
            gotoxy(x, y);
            age = Console.ReadLine();
            while (isCnicCheck(age) || age.Length > 2)
            {
                gotoxy(x, y + 1);
                Console.WriteLine("WRONG DATA PLEASE ENTER CORRECT AGE ");
                gotoxy(x, y + 2);
                Console.WriteLine("Press any key for going back  ");
                Console.ReadKey();
                gotoo11(x, y);
                age = Console.ReadLine();
            }
            return age;
        }
        static string numberChec1(int x, int y)
        {
            string phone;
            gotoxy(x, y);
            phone = Console.ReadLine();
            while ((phone.Length < 11 || phone.Length > 11) || isCnicCheck(phone))
            {
                gotoxy(x, y + 1);
                Console.WriteLine("WRONG DATA PLEASE ENTER YOUR GENDER FROM GIVEN OPTIONS  ");
                gotoxy(x, y + 2);
                Console.WriteLine("Press any key for going back  ");
                Console.ReadKey();
                gotoo11(x, y);
                phone = Console.ReadLine();
            }
            return phone;
        }
  
        
        static void gotoo11(int x, int y)
        {
            gotoxy(x, y);
            erase6(x, y);
            gotoxy(x, y);
        }
        static void erase6(int x, int y)
        {
            gotoxy(x, y);
            Console.WriteLine("                                                         ");
            gotoxy(x, y + 1);
            Console.WriteLine("                                                          ");
            gotoxy(x, y + 2);
            Console.WriteLine("                                                          ");
            gotoxy(x, y + 3);
            Console.WriteLine("                                                          ");
            gotoxy(x, y + 4);
            Console.WriteLine("                                                          ");
            gotoxy(x, y + 5);
            Console.WriteLine("                                                          ");
        }
        static bool isCnicCheck(string word)
        {
            int coun;
            coun = word.Length;
            bool result = true;
            int length = 0;
            for (int x = 0; x < coun; x = x + 1)
            {
                if (word[x] >= '0' && word[x] <= '9')
                {
                    length = length + 1;
                }
            }
            if (length == coun)
            {
                result = false;
            }
            return result;
        }
        static bool isDomicileCheck2(string word)
        {
            int coun;
            coun = word.Length;
            bool result = true;
            int length = 0;
            for (int x = 0; x < coun; x = x + 1)
            {
                if (word[x] == '1' || word[x] == '0' || word[x] == '2' || word[x] == '3' || word[x] == '4' || word[x] == '5' || word[x] == '6' || word[x] == '7' || word[x] == '8' || word[x] == '9' || word[x] == '!' || word[x] == '@' || word[x] == '#' || word[x] == '%' || word[x] == '$' || word[x] == '(' || word[x] == ')' || word[x] == '*' || word[x] == '^' || word[x] == '+' || word[x] == '-')
                {
                    length = length + 1;
                }
            }
            if (length == 0)
            {
                result = false;
            }
            return result;
        }
        static int numericChec(int x, int y)
        {
            string phone;
            gotoxy(x, y);
            phone = Console.ReadLine();
            while (isCnicCheck(phone))
            {
                gotoxy(x, y + 1);
                 Console.WriteLine("please enter data in correct format ");
                gotoxy(x, y + 2);
                Console.WriteLine("Press any key for going back  ");
                Console.ReadKey();
                gotoo11(x, y);
                phone = Console.ReadLine();
            }

            return int.Parse(phone);
        }
    }
}


