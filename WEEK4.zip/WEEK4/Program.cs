﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WEEK4
{
  class Program
  {
    static void Main(string[] args)
    {
      List<Product> products = new List<Product>();
      string option = "";
      while (option != "6")
      {
        option = MainMenu();
        if (option == "1")
        {
          products.Add(AddProduct());
        }
        if(option == "2")
        {
          UpdateProduct(products);
        }
          if(option == "3")
        {
          RemoveProduct(products);
        }
        if(option == "4")
        {
          DisplayPatient(products);
        }
         if(option == "5")
        {
          Environment.Exit(0);
        }
      }
    }
    static string MainMenu()
    {
      int IX = 10, IY = 8;
      Console.Clear();
      string option;
      gotoxy(IX, IY);
      Thread.Sleep(100);
      Console.WriteLine(" Enter option");
      gotoxy(IX, IY + 3);
      Thread.Sleep(100);
      Console.WriteLine(" 1- Add Product ");
      gotoxy(IX, IY + 5);
      Thread.Sleep(100);
      Console.WriteLine(" 2- Update Products");
      gotoxy(IX, IY + 7);
      Thread.Sleep(100);
      Console.WriteLine(" 3- Remove products");
      gotoxy(IX, IY + 9);
      Thread.Sleep(100);
      Console.WriteLine(" 4- Display products ");
      gotoxy(IX, IY + 11);
      Thread.Sleep(100);
      Console.WriteLine(" 5- Exit");
      gotoxy(IX + 1, IY + 13);
      option = Console.ReadLine();
      return option;
    }
    static void gotoxy(int x, int y)
    {
      Console.SetCursorPosition(x, y);
    }
    static Product AddProduct()
    {
      int IX = 10, IY = 12;
      Console.Clear();
      string ProductName = "", ProductCategory = "";
      int ProductPrice = 0, StockQuantity = 0, MinimumQuantity = 0;
      Product product = new Product(ProductName, ProductCategory, ProductPrice, StockQuantity, MinimumQuantity);
      gotoxy(IX + 4, IY);
      Console.Write("Enter Product's Name  : ");
      ProductName = Console.ReadLine();
      gotoxy(IX + 4, IY + 2);
      Console.Write("Enter Product's Category  : ");
      ProductCategory = Console.ReadLine();
      gotoxy(IX + 4, IY + 4);
      Console.Write("Enter Product's Price : ");
      ProductPrice = int.Parse(Console.ReadLine());
      gotoxy(IX + 4, IY + 6);
      Console.Write("Enter Stock Quantity  : ");
      StockQuantity = int.Parse(Console.ReadLine());
      gotoxy(IX + 4, IY + 8);
      Console.Write("Enter Minimum Quantity  : ");
      MinimumQuantity = int.Parse(Console.ReadLine());
      gotoxy(IX + 4, IY + 10);
      Product products = new Product(ProductName, ProductCategory, ProductPrice, StockQuantity, MinimumQuantity);
      return products;
    }
    static void UpdateProduct(List<Product> products)
    {
      Console.Clear();
      int IX = 10, IY = 8;
      string Name = "";
      Console.Write("Enter the name of the product you want to update  :");
      Name = Console.ReadLine();
      foreach (var x in products)
      {
        if (x.ProductName == Name)
        {
          gotoxy(IX + 4, IY);
          Console.Write("Enter Product's Name  : ");
          x.ProductName = Console.ReadLine();
          gotoxy(IX + 4, IY + 2);
          Console.Write("Enter Product's Category  : ");
          x.ProductCategory = Console.ReadLine();
          gotoxy(IX + 4, IY + 4);
          Console.Write("Enter Product's Price : ");
          x.ProductPrice = int.Parse(Console.ReadLine());
          gotoxy(IX + 4, IY + 6);
          Console.Write("Enter Stock Quantity  : ");
          x.StockQuantity = int.Parse(Console.ReadLine());
          gotoxy(IX + 4, IY + 8);
          Console.Write("Enter Minimum Quantity  : ");
          x.MinimumQuantity = int.Parse(Console.ReadLine());
          gotoxy(IX + 4, IY + 10);
        }
      }
    }
    static void RemoveProduct(List<Product> products)
    {
      Console.Clear();
      string Name = "";
      Console.Write("Enter the name of the product you want to remove  :");
      Name = Console.ReadLine();
      foreach(var x in products)
      {
        if(x.ProductName == Name)
        {
          products.Remove(x);
        }
      }
    }
    static void DisplayPatient(List<Product> products)
    {
      Console.Clear();
      Console.WriteLine("ProductName".PadRight(15) + "ProductCategory".PadRight(15) +  "ProductPrice".PadRight(15) + "StockQuantity".PadRight(15) + "MinimumQuantity".PadRight(15));
      foreach(var x in products)
      {
        Console.WriteLine(x.ProductName.PadRight(15) + x.ProductCategory.PadRight(15) +  x.ProductPrice.ToString().PadRight(15) + x.StockQuantity.ToString().PadRight(15) + x.MinimumQuantity.ToString().PadRight(15));
      }
    }
  }
}
