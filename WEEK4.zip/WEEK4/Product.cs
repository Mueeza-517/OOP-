using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WEEK4
{
    public class Product
    {
        public string ProductName;
        public string ProductCategory;
        public int ProductPrice;
        public int StockQuantity;
        public int MinimumQuantity;

        public Product(string ProductName = null, string ProductCategory = null, int ProductPrice = 0, int StockQuantity = 0, int MinimumQuantity = 0)
        {
          this.ProductName = ProductName;
          this.ProductCategory = ProductCategory;
          this.ProductPrice = ProductPrice;
          this.StockQuantity = StockQuantity;
          this.MinimumQuantity = MinimumQuantity;
        }
    }
}